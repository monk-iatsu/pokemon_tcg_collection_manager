BASIC_ENERGY = {
    "fy": "Fairy",
    "fg": "Fighting",
    "fr": "Fire",
    "gs": "Grass",
    "lg": "Lightning",
    "ml": "Metal",
    "pc": "Psychic",
    "wr": "Water",
    "ds": "Darkness"
}
ENERGY_TYPES = BASIC_ENERGY
ENERGY_TYPES["dn"] = "Dragon"
ENERGY_TYPES["cs"] = "Colorless"
ENERGY_PRINT_TYPES = ("normal", "reverseHolofoil")
ITERATIONS = 1000000
LRU_CACHE_EXPO = 15
