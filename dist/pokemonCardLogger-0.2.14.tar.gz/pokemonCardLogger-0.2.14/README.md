# pokemon_tcg_collection_manager
A cli tool/library to manage, store and analyze a pokemon card collection
## Prerequisits:
* python3.10
* pip3 in path
* python3.10 in path
## Installation:
* run `pip3 install pokemonCardLogger`
## Use as a library:
* `from pokemonCardLogger import clss_pickle as pcl` or `from pokemonCardLogger import clss_json as pcl`
